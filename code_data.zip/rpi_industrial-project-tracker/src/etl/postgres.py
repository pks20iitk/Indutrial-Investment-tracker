import psycopg2
from psycopg2 import pool

host = "c-indutrial-tracker.6kh5jbizl437id.postgres.cosmos.azure.com"
dbname = "citus"
user = "citus"
password = "Physicsguru92@"
sslmode = "require"

conn_string = "host={0} user={1} dbname={2} password={3} sslmode={4}".format(host, user, dbname, password, sslmode)

postgreSQL_pool = psycopg2.pool.SimpleConnectionPool(1, 20,conn_string)
if (postgreSQL_pool):
    print("Connection pool created successfully")

conn = postgreSQL_pool.getconn()

cursor = conn.cursor()

# Drop previous table of same name if one exists
# cursor.execute("DROP TABLE IF EXISTS pharmacy;")
# print("Finished dropping table (if existed)")

# cursor.execute("CREATE TABLE pharmacy (pharmacy_id integer, pharmacy_name text, city text, state text, zip_code integer);")
# print("Finished creating table")

# cursor.execute("CREATE INDEX idx_pharmacy_id ON pharmacy(pharmacy_id);")
# print("Finished creating index")

# cursor.execute("INSERT INTO pharmacy  (pharmacy_id,pharmacy_name,city,state,zip_code) VALUES (%s, %s, %s, %s,%s);", (1,"Target","Sunnyvale","California",94001))
# cursor.execute("INSERT INTO pharmacy (pharmacy_id,pharmacy_name,city,state,zip_code) VALUES (%s, %s, %s, %s,%s);", (2,"CVS","San Francisco","California",94002))
# print("Inserted 2 rows of data")

# # Clean up
# conn.commit()

# cursor.execute("SELECT * FROM pharmacy;")
# rows = cursor.fetchall()

# # Print all rows
# for row in rows:
#     print("Data row = (%s, %s)" %(str(row[0]), str(row[1])))

cursor.execute("DELETE FROM CHANGEFEED;")
print("DELETES")
conn.commit()
cursor.close()
conn.close()

# cursor.close()
# conn.close()