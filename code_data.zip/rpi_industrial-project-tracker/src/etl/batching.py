import time
import signal
from threading import Event, Thread

from utils import process_json_objects
from vector_index import upload_documents
from config import AZURE_SEARCH_INDEX


class Batching:
    def __init__(self, max_batch_size, batch_timeout):
        self._queue = []
        self.queue = []
        self._max_batch_size = max_batch_size
        self._last_batch_sent = time.time()
        self._batch_timeout = batch_timeout

        self._cancel_processing = Event()
        self._cancel_consuming = Event()
        signal.signal(signal.SIGINT, self.cancel)

        self._thread = Thread(target=self._consume, daemon=True)
        self._thread.start()

        self._consume_thread = Thread(target=self.consume, daemon=True)
        self._consume_thread.start()

    def cancel(self, signal, frame):
        self._cancel_processing.set()
        self._thread.join()
        self._consume_thread.join()

    def put(self, data):
        self._queue.append(data)

    def _process_batch(self, batch):
        processed_batch = process_json_objects(batch)
        if processed_batch:
            self.queue.append(processed_batch)

    def _consume(self):
        while not self._cancel_processing.is_set():
            if (self._queue and (len(self._queue) >= self._max_batch_size)) or (
                (time.time() - self._last_batch_sent) >= self._batch_timeout
            ):
                batch = self._queue[: self._max_batch_size]
                self._queue = self._queue[self._max_batch_size :]
                self._last_batch_sent = time.time()
                self._process_batch(batch)
            time.sleep(1)

    def consume(self):
        while not self._cancel_consuming.is_set():
            if self.queue:
                batched_index_data = self.queue.pop(0)
                print(f"Read from queue to save in Vector Search Index '{AZURE_SEARCH_INDEX}'")
                upload_documents(AZURE_SEARCH_INDEX, batched_index_data)
            time.sleep(2)