import os
import sys
import json
import scrapy

from datetime import datetime
from ..items import AreadevelopmentItem

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from config import SCRAPY_LOG


class NewsSpider(scrapy.Spider):
    name = "news"
    start_urls = ["https://www.areadevelopment.com/newsItems/"]

    def __init__(self, *args, **kwargs):
        super(NewsSpider, self).__init__(*args, **kwargs)
        self.file = open(SCRAPY_LOG, "a")

    def closed(self, reason):
        self.file.close()

    def parse(self, response):
        news_items = response.css("div#newsItems article a::attr(href)").getall()
        for news_item_url in news_items:
            full_url = response.urljoin(news_item_url)
            yield scrapy.Request(url=full_url, callback=self.parse_news_item)

    def parse_news_item(self, response):
        item = AreadevelopmentItem()
        item["article_text"] = " ".join(
            response.css("section.areaArticleBody::text").getall()
        )
        item["link"] = response.url
        item["title"] = response.css("h1::text").get()
        item["scrap_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        item_dict = dict(item)
        self.file.write(json.dumps(item_dict) + "\n") 
        yield item