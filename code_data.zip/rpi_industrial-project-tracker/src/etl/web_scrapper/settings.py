BOT_NAME = "web_scrapper"
SPIDER_MODULES = ["web_scrapper.spiders"]
NEWSPIDER_MODULE = "web_scrapper.spiders"
ROBOTSTXT_OBEY = True
FEED_EXPORT_ENCODING = "utf-8"
REQUEST_FINGERPRINTER_IMPLEMENTATION = "2.7"
