from itemadapter import ItemAdapter

class AreadevelopmentPipeline:
    def process_item(self, item, spider):
        adapter = ItemAdapter(item)
        spider.logger.info(f"Processing item: {adapter.asdict()}")
        return item
