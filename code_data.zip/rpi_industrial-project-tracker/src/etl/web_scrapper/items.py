import scrapy

class AreadevelopmentItem(scrapy.Item):
    title = scrapy.Field()
    link = scrapy.Field()
    article_text = scrapy.Field()
    scrap_time = scrapy.Field()