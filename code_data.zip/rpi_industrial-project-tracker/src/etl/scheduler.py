import os
import time
import json
import schedule
import subprocess
from threading import Thread

from change_data_capture_postgres import ChangeDataCapture


class ScrapyScheduler:
    def __init__(self):
        self.jsonl_file = os.path.join("logs", "scraped_news.jsonl")
        self._change_data_capture = ChangeDataCapture()
        self._consume_thread = Thread(target=self.process_file, daemon=True)
        self._consume_thread.start()

    def process_file(self):
        while True:
            if os.path.exists(self.jsonl_file):
                try:
                    with open(self.jsonl_file, "r") as file:
                        for line in file:
                            line = line.strip()
                            try:
                                data = json.loads(line)
                                self._change_data_capture.cdc_handler(data)
                            except json.JSONDecodeError as e:
                                print(f"Error decoding JSON: {e}")
                except IOError as e:
                    print(f"Error reading file: {e}")
            time.sleep(1)

    def crawl_news(self):
        try:
            subprocess.run(["scrapy", "crawl", "news"], check=True)
        except subprocess.CalledProcessError as e:
            print(f"An error occurred while crawling: {e}")

    def start(self):
        schedule.every().day.at("10:00").do(self.crawl_news)
        # schedule.every(5).seconds.do(self.crawl_news)
        while True:
            schedule.run_pending()
            time.sleep(1)


if __name__ == "__main__":
    scheduler = ScrapyScheduler()
    # scheduler.start()
    scheduler.process_file()