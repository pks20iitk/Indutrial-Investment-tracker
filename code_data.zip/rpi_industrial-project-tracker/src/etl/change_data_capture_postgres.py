import os
import json
from datetime import datetime
from pymongo import MongoClient
import psycopg2
from psycopg2 import pool
 
from dotenv import load_dotenv
from config import CDC_DB, CDC_TABLE
from prompts import FILTER_PROMPT, get_filter_prompt, get_cosmos_prompt_template
from llm import get_llm_response
from batching import Batching
from vector_index import create_index
from blobstore import save_to_blob
from utils import format_cosmos_data
load_dotenv()
 
# PostgreSQL connection details
host = os.getenv("POSTGRES_HOST")
dbname = os.getenv("POSTGRES_DB")
user = os.getenv("POSTGRES_USER")
password = os.getenv("POSTGRES_PASSWORD")
sslmode = "require"
 
conn_string = "host={0} user={1} dbname={2} password={3} sslmode={4}".format(host, user, dbname, password, sslmode)
postgreSQL_pool = psycopg2.pool.SimpleConnectionPool(1, 40, conn_string)

class ChangeDataCapture:
    def __init__(self) -> None:
        self.table = CDC_TABLE
        self._create_table()
        self.cosmos_client = MongoClient(os.getenv("AZURE_COSMOSDB_STORAGE_CONNECTION_STRING"))
        self.cosmos_db = self.cosmos_client[os.getenv("COSMOS_DB_NAME")]
        self.cosmos_collection = self.cosmos_db[os.getenv("COSMOS_DB_COLLECTION_NAME")]
        create_index(os.getenv("AZURE_SEARCH_INDEX"))
        self.batcher = Batching(max_batch_size=10, batch_timeout=220)
 
    def _create_table(self):
        try:
            conn = postgreSQL_pool.getconn()
            cursor = conn.cursor()
            cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {self.table} (
                title TEXT PRIMARY KEY,
                last_change TIMESTAMP
            )
            """)
            conn.commit()
            postgreSQL_pool.putconn(conn)
        except psycopg2.Error as e:
            print("Error creating table: ", e)
 
    def _filter_news(self, data):
        prompt = get_filter_prompt(data)
        print("filter_prompt ::", prompt)
        print("________________________")
        response = get_llm_response(prompt)
        # print("response_prompt ::", response)
        # response_json = convert_improper_json_to_proper_json(response)
        # print("response_json ::", response_json)
        output = json.loads(response)
        try:
            if output["relevancy"] and output["score"]:
                return output if output["relevancy"].lower() in ["yes", "1"] else None
        except Exception as e:
            print(f"Error processing filter response: {e}")
            return None
 
    def cdc_handler(self, content):
        if content:
            title = content["title"]
            try:
                conn = postgreSQL_pool.getconn()
                cursor = conn.cursor()
                cursor.execute(f"SELECT title FROM {self.table} WHERE title = %s", (title,))
                result = cursor.fetchone()
                if not result:
                    last_change = datetime.now()
                    cursor.execute(
                        f"INSERT INTO {self.table} (title, last_change) VALUES (%s, %s)",
                        (title, last_change),
                    )
                    conn.commit()
                    output = self._filter_news(content)
                    if output:
                        save_to_blob(output)
                        cosmos_prompt = get_cosmos_prompt_template(content["article_text"])
                        cosmos_response = get_llm_response(cosmos_prompt)
                        cosmos_data = format_cosmos_data(output, cosmos_response)
                        self.cosmos_collection.insert_one(cosmos_data)
                        self.batcher.put(cosmos_data)
                else:
                    print("Duplicate entry found:", result)
                postgreSQL_pool.putconn(conn)
            except psycopg2.Error as e:
                print("Error in CDC handler: ", e)
 
if __name__ == "__main__":
    cdc = ChangeDataCapture()
    jsonl_file = "logs/scraped_news.jsonl"
    i = 0
    with open(jsonl_file, "r") as file:
        for line in file:
            line = line.strip()
            data = json.loads(line)
            cdc.cdc_handler(data)
            i += 1
 
            if i == 4:
                break