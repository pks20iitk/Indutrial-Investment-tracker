import json
import uuid
from llm import get_llm_response
from langchain import PromptTemplate
# from langchain.llms import OpenAI
from llm import get_embeddings


def format_cosmos_data(data, response):
    data_dict = json.loads(response)
    data_dict["title"] = data["title"]
    data_dict["link"] = data["link"]
    data_dict["article_text"] = data["article_text"]
    return data_dict


def process_json_objects(json_objects):
    stories = []

    for json_obj in json_objects:
        story = ""
        story += f"**Title:** {json_obj.get('title', '')}\n\n"
        story += f"**Company Name:** {json_obj.get('company_name', '')}\n\n"
        story += f"**Locational References:** {json_obj.get('locational_references', '')}\n\n"
        story += f"**Operation Type:** {json_obj.get('operation_type', '')}\n\n"
        story += (
            f"**Products or Services:** {json_obj.get('products_or_services', '')}\n\n"
        )
        if (
            json_obj.get("building_or_land")
            and "building" in json_obj.get("building_or_land").lower()
        ):
            story += f"**Building or Land:** Building a new facility with a square footage of {json_obj.get('square_footage', '')}\n\n"
        elif (
            json_obj.get("building_or_land")
            and "land" in json_obj.get("building_or_land").lower()
        ):
            story += f"**Building or Land:** Acquiring land with an acreage of {json_obj.get('acreage', '')}\n\n"
        else:
            story += f"**Building or Land:** {json_obj.get('building_or_land', '')}\n\n"
        story += f"**Capital Investment:** {json_obj.get('capital_investment', '')}\n\n"
        story += f"**Jobs Created:** {json_obj.get('jobs_created', '')}\n\n"
        story += f"**Involved Parties:** {json_obj.get('involved_parties', '')}\n\n"
        story += f"**Source Link:** {json_obj.get('link', '')}"

        stories.append(story)

    if stories:
        merged_stories = "\n\n---\n\n".join(stories)
        json_object = {"content": merged_stories}
        json_object["id"] = str(uuid.uuid4())
        json_object["embedding_content"] = get_embeddings(json_object["content"])
        print("Batched Content Embeddings Created")
        return json_object
    
 

 
# Define a prompt template for fixing JSON
prompt_template = PromptTemplate(
    input_variables=["invalid_json"],
    template="Fix the following invalid JSON: {invalid_json}"
)
 
# # Create an LLMChain with the prompt template and the model
# llm_chain = LLMChain(prompt=prompt_template, llm=get_llm_response)
 
# def convert_improper_json_to_proper_json(invalid_json):
#     # Use the LLMChain to generate a fixed JSON
#     response = llm_chain.run(invalid_json=invalid_json)
#     # Attempt to parse the response as JSON
#     try:
#         fixed_json = json.loads(response)
#         return fixed_json
#     except json.JSONDecodeError:
#         print("Failed to fix the JSON.")
#         return None
 