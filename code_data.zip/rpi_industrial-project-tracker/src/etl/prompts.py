# FILTER_PROMPT = """Please apply the below filtering criteria to the json that is a scrapped news article. You need to inspect the "article_text" in each of these news articles. After your inspection, you have to return a json where you add new fields to the original input json. The fields are "relevancy" and "score". The relevancy should be yes for relevant news articles and no otherwise. The score should be between 0 to 1.
# Filtering Criteria:
# Industry: Articles related to the following industries:
# Manufacturing
# Chemical
# Warehouse Logistics
# Oil and Gas
# Heavy Industry
# Automobile
# Power Generation
# Mining
# Steel
# Agriculture
# Port Industries
# Additionally, consider articles from related industries such as:
# Construction
# Energy
# Infrastructure
# Transportation
# Supply Chain Management
# Keywords/Terms:
# Business
# Industrial
# Financial
# Investments
# Expansions
# Acquisitions
# Mergers
# Development
# Growth
# Construction
# Infrastructure
# Upgrade
# Modernization
# Relocation
# New facility
# New plant
# Capacity increase
# Capital expenditure
# Article Content: Filter articles that contain information about companies in the specified industries that are:
# Planning or executing new resource acquisitions
# Expanding their operations or capacity
# Building new plants or facilities
# Relocating or switching to a new location
# Investing in new equipment or technology
# Announcing capital expenditure plans
# Engaging in mergers and acquisitions
# Geographic Location: Consider articles from news websites covering news from:
# Global markets
# Regional markets (e.g. North America, Europe, Asia-Pacific, etc.)
# Country-specific markets (e.g. USA, China, India, etc.)
# Article Filtering Goals:
# The goal of filtering these news articles is to identify potential leads from the specified industries that may require goods train logistics support for their business operations. The filtered articles should provide insights into companies that are expanding, diversifying, or investing in new resources, which would necessitate logistics services to support their growth.
# By filtering news articles based on these criteria, you should be able to identify companies that are likely to require goods train logistics support, enabling you to proactively approach them with your services and support their business growth.

# The ouput json format should be strictly in:
# {"article_text": <CONTENT>, "link": <LINK>, "title": <TITLE>, "scrap_time": <TIME>, "relevancy": <VAL>, "score": <VAL>}

# Please don't add any extra text apart from the json.

# {data}
# """
FILTER_PROMPT = """Please apply the below filtering criteria to the json mentioned below under `DATA:' that is a scrapped news article. You need to inspect the "article_text" in each of these news articles. After your inspection, you have to return a json where you add new fields to the original input json. The fields are "relevancy" and "score". The relevancy should be yes for relevant news articles and no otherwise. The score should be between 0 to 1.

Filtering Criteria: Industry: Articles related to the following industries: Manufacturing Chemical Warehouse Logistics Oil and Gas Heavy Industry Automobile Power Generation Mining Steel Agriculture Port Industries Additionally, consider articles from related industries such as: Construction Energy Infrastructure Transportation Supply Chain Management Keywords/Terms: Business Industrial Financial Investments Expansions Acquisitions Mergers Development Growth Construction Infrastructure Upgrade Modernization Relocation New facility New plant Capacity increase Capital expenditure Article Content: Filter articles that contain information about companies in the specified industries that are: Planning or executing new resource acquisitions Expanding their operations or capacity Building new plants or facilities Relocating or switching to a new location Investing in new equipment or technology Announcing capital expenditure plans Engaging in mergers and acquisitions Geographic Location: Consider articles from news websites covering news from: Global markets Regional markets (e.g. North America, Europe, Asia-Pacific, etc.) Country-specific markets (e.g. USA, China, India, etc.) Article Filtering Goals: The goal of filtering these news articles is to identify potential leads from the specified industries that may require goods train logistics support for their business operations. The filtered articles should provide insights into companies that are expanding, diversifying, or investing in new resources, which would necessitate logistics services to support their growth.

By filtering news articles based on these criteria, you should be able to identify companies that are likely to require goods train logistics support, enabling you to proactively approach them with your services and support their business growth.

Important: The output json should be strictly formatted as follows and don't any kind of word like ```json output must be in pure json formats only:

{{
    "article_text": <CONTENT>,
    "link": <LINK>,
    "title": <TITLE>,
    "scrap_time": <TIME>,
    "relevancy": <VAL>,
    "score": <VAL>
}}

DATA: {data}
"""

ENTITY_EXTRACTION_PROMPT = """
Please read the following text and answer the questions below to extract the necessary information:
{blob_content}

Question 1: What is the name of the company mentioned in the text, and provide strictly very small context about it?
Question 2: What are the locational references mentioned in the text, such as address, lat/long, industrial park or site name, city/state, etc., and provide strictly very small context about them?
Question 3: Is the company building a new facility or just acquiring land at the location mentioned in the text, and provide strictly very small context about it?
Question 4: If the company is building a new facility, how much acreage is involved, and provide strictly very small context about it?
Question 5: If the company is building a new facility, what is the square footage of the building, and provide strictly very small context about it?
Question 6: What type of operation is the company engaged in at the location mentioned in the text, and provide strictly very small context about it?
Question 7: What products or services does the company offer at the location mentioned in the text, and provide strictly very small context about them?
Question 8: What is the capital investment involved in the project at the location mentioned in the text, and provide strictly very small context about it? Mention the $ symbol and use millions, billions, etc. as appropriate.
Question 9: How many jobs will be created as a result of the project at the location mentioned in the text, and provide strictly very small context about it?
Question 10: Who are the involved parties or partners, such as power provider, county officials, economic developers, railroad, in the project at the location mentioned in the text, and provide strictly very small context about them?

Please provide the extracted information strictly in a JSON-like format for reference. One example is given below:

{{
    "company_name": "Answer to Question 1",
    "locational_references": "Answer to Question 2",
    "building_or_land": "Answer to Question 3",
    "acreage": "Answer to Question 4",
    "square_footage": "Answer to Question 5",
    "operation_type": "Answer to Question 6",
    "products_or_services": "Answer to Question 7",
    "capital_investment": "Answer to Question 8",
    "jobs_created": "Answer to Question 9",
    "involved_parties": "Answer to Question 10"
}}
"""

def get_cosmos_prompt_template(blob_content):
    messages = [
        {
            "role": "system",
            "content": "You are a helpful assistant that can extract information from a given text using the provided questions. Your task is to convert the extracted entities into a JSON-like dictionary format. Make sure to include strictly very small context in your answers and format the JSON strictly as per the example provided.",
        },
        {
            "role": "user",
            "content": ENTITY_EXTRACTION_PROMPT.format(blob_content=blob_content),
        },
    ]
    return messages


def get_filter_prompt(data):
    messages = [
        {
            "role": "system",
            "content": "",
        },
        {
            "role": "user",
            "content": FILTER_PROMPT.format(data=data),
        },
    ]
    return messages
    