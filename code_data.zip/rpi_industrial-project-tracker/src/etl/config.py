SCRAPY_LOG = "logs\scraped_news.jsonl"
CDC_DB="logs\cdc_record_manager.db"
CDC_TABLE="CHANGEFEED"

AZURE_BLOB_CONTAINER_NAME="newsscrapping"

COSMOS_DB_NAME="indutrialtracker-db"
COSMOS_DB_COLLECTION_NAME="indutrial-collections"

AZURE_SEARCH_INDEX="embedded"
AZURE_SEARCH_ENDPOINT="https://investmenttracker.search.windows.net"
EMBEDDING_MODEL_NAME="text-embedding-3-large"

AZURE_OPENAI_ENDPOINT="https://investment-tracker.openai.azure.com/"
AZURE_OPENAI_VERSION="2024-02-01"
LLM_NAME="gpt-4"
