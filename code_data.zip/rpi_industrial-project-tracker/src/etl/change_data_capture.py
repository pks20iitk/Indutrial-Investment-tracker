import os
import sqlite3
from datetime import datetime
import json
from pymongo import MongoClient

from dotenv import load_dotenv
from config import CDC_DB, CDC_TABLE
from prompts import FILTER_PROMPT, get_filter_prompt, get_cosmos_prompt_template
from llm import get_llm_response
from batching import Batching
from vector_index import create_index
from blobstore import save_to_blob
from utils import format_cosmos_data

from config import (
    COSMOS_DB_NAME,
    COSMOS_DB_COLLECTION_NAME,
    AZURE_SEARCH_INDEX,
)

load_dotenv()
AZURE_COSMOSDB_STORAGE_CONNECTION_STRING = os.environ[
    "AZURE_COSMOSDB_STORAGE_CONNECTION_STRING"
]


class ChangeDataCapture:
    def __init__(self) -> None:
        self.table = CDC_TABLE
        self._create_table()
        self.cosmos_client = MongoClient(AZURE_COSMOSDB_STORAGE_CONNECTION_STRING)
        self.cosmos_db = self.cosmos_client[COSMOS_DB_NAME]
        self.cosmos_collection = self.cosmos_db[COSMOS_DB_COLLECTION_NAME]
        create_index(AZURE_SEARCH_INDEX)
        self.batcher = Batching(max_batch_size=6, batch_timeout=120)

    def _create_table(self):
        try:
            with sqlite3.connect(CDC_DB, check_same_thread=False) as conn:
                conn.execute(f"""
                CREATE TABLE IF NOT EXISTS {self.table} (
                    title TEXT PRIMARY KEY,
                    last_change TEXT
                )             
                """)
        except sqlite3.Error as e:
            print("Error creating table: ", e)

    def _filter_news(self, data):
        prompt = get_filter_prompt(data)
        response = get_llm_response(prompt) # issue is here we need a json parser
        output = json.loads(response)

        try:
            if output["relevancy"] and output["score"]:
                return output if output["relevancy"].lower() in ["yes", "1"] else None
        except Exception as e:
            print(f"Error processing filter response: {e}")
            return None

    def cdc_handler(self, content):
        if content:
            title = content["title"]
            try:
                with sqlite3.connect(CDC_DB, check_same_thread=False) as conn:
                    cursor = conn.cursor()
                    cursor.execute(
                        f"SELECT title FROM {self.table} WHERE title = ?", (title,)
                    )
                    result = cursor.fetchone()
                    print("result: ", result)
                    if not result:
                        last_change = datetime.today().isoformat()
                        cursor.execute(
                            f"INSERT INTO {self.table} (title, last_change) VALUES (?, ?)",
                            (title, last_change),
                        )
                        conn.commit()
                        output = self._filter_news(content)
                        if output:
                            save_to_blob(output)
                            print("==================Saved to blob===========================")
                            cosmos_prompt = get_cosmos_prompt_template(content["article_text"])
                            cosmos_response = get_llm_response(cosmos_prompt)
                            cosmos_data = format_cosmos_data(output, cosmos_response)
                            self.cosmos_collection.insert_one(cosmos_data)
                            print("==================Saved to Cosmos=========================")
                            self.batcher.put(cosmos_data)
                            print("===============Item queued to batch index=================")
                    else:
                        print("Duplicate entry found:", result)
            except sqlite3.IntegrityError as e:
                print("UNIQUE constraint failed: Title already exists", e)
            except sqlite3.Error as e:
                print("Error in CDC handler: ", e)

if __name__ == "__main__":
     cdc = ChangeDataCapture()
     jsonl_file = "logs\scraped_news.jsonl"
     i = 0
     with open(jsonl_file, "r") as file:
        for line in file:
            line = line.strip()
            data = json.loads(line)
            cdc.cdc_handler(data)
            i += 1

            if  i == 4:
                break