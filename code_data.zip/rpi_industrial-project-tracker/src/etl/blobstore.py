import os
from azure.storage.blob import BlobServiceClient
from dotenv import load_dotenv

load_dotenv()


class AzureBlobStoragePipeline:
    def __init__(self):
        self.connection_string = os.environ["AZURE_BLOB_STORAGE_CONNECTION_STRING"]
        self.container_name = os.environ["AZURE_BLOB_CONTAINER_NAME"]
        self.blob_service_client = BlobServiceClient.from_connection_string(
            self.connection_string
        )
        self.container_client = self.blob_service_client.get_container_client(
            self.container_name
        )

    def process_item(self, item):
        blob_name = f"{item['title']}.txt"
        blob_client = self.container_client.get_blob_client(blob_name)
        blob_content = item["article_text"]
        blob_client.upload_blob(blob_content, overwrite=True)
        blob_client.set_blob_metadata(
            metadata={"title": item["title"], "link": item["link"]}
        )


azure_blob_client = AzureBlobStoragePipeline()


def save_to_blob(news_data):
    azure_blob_client.process_item(news_data)