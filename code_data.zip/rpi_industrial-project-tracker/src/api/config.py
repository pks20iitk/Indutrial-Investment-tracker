SEARCH_SERVICE_ENDPOINT="https://investmenttracker.search.windows.net"
INDEX_NAME="i-tracker-prod"
EMBEDDING_MODEL_NAME="text-embedding-3-large"

API_VERSION="2024-02-01"
AZURE_ENDPOINT="https://investment-tracker.openai.azure.com/"

GENERATIVE_MODEL_NAME = "gpt-4"