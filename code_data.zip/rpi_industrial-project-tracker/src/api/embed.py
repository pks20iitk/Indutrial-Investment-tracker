import os
from openai import AzureOpenAI
from config import API_VERSION, AZURE_ENDPOINT

from dotenv import load_dotenv

load_dotenv()

client = AzureOpenAI(
    api_key=os.environ["API_KEY"],
    api_version=API_VERSION,
    azure_endpoint=AZURE_ENDPOINT,
)


def get_embeddings(text, model):
    return client.embeddings.create(input=text, model=model).data[0].embedding