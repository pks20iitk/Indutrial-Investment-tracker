import os
import streamlit as st
from fastapi import FastAPI
from openai import AzureOpenAI
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from azure.core.credentials import AzureKeyCredential
from embed import get_embeddings
from dotenv import load_dotenv
 
from config import (
    SEARCH_SERVICE_ENDPOINT,
    INDEX_NAME,
    EMBEDDING_MODEL_NAME,
    API_VERSION,
    AZURE_ENDPOINT,
    GENERATIVE_MODEL_NAME,
)
 
load_dotenv()
CREDENTIALS = AzureKeyCredential(os.environ["AZURE_AI_SEARCH_KEY"])
KEY = os.environ["API_KEY"]
search_client = SearchClient(SEARCH_SERVICE_ENDPOINT, INDEX_NAME, CREDENTIALS)

CREDENTIALS = AzureKeyCredential(os.environ["AZURE_AI_SEARCH_KEY"])
KEY = os.environ["API_KEY"]
 
 
def search(query: str, top_k: int = 6):
    query_vector = get_embeddings(query, model=EMBEDDING_MODEL_NAME)
    vector_query = VectorizedQuery(
        vector=query_vector, k_nearest_neighbors=3, fields="embedding_content"
    )
    results = search_client.search(
        search_text=query, vector_queries=[vector_query], select=["content"], top=top_k
    )  
    result_content = ""
    for result in results:
        result_content += f"* {result['content']}\n"
    return {"result": result_content}

def generate(query: str):
    context = search(query, 6)
    context_info = context["result"]
    messages = [
        {
            "role": "system",
            "content": f"As a expert, you have given {query} and content read query carefully and give answer from content you possess exceptional skills in comprehending and analyzing context, as well as a strong foundation in logic, mathematics, and reasoning. Your primary responsibility is to generate accurate and relevant responses based solely on the context provided. In cases where the required information is not available, you should clearly indicate that the information is missing. Additionally, your responses should be good in presentation for user, coherent, and captivating, making it easy and enjoyable for users to read and understand",
        },
        {"role": "user", "content": context_info},
    ]
 
    client = AzureOpenAI(
        api_key=KEY,
        api_version=API_VERSION,
        azure_endpoint=AZURE_ENDPOINT,
    )
 
    completion = client.chat.completions.create(
        model=GENERATIVE_MODEL_NAME, messages=messages, max_tokens=800
    )
 
    ans = completion.choices[0].message.content.strip()
    return ans

st.title("Investment Tracker Chatbot")
st.write("Enter your query below:")

query = st.text_input("Query", placeholder="Ask me anything...")


if st.button("Search"):
    response = generate(query)
    st.write("Generated Response:")
    st.write(f"**{response}**")

# Add some visual flair
st.write("")
st.write("")
st.write("")
